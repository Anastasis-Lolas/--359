package coreservlets;

public class TmpClass {
  static int  tmpMessage() {
	  return 18;
  }
}
